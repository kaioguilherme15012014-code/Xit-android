package com.aixit.painel;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends Activity {
    private LinearLayout root, content, tabs;
    private int pink = Color.rgb(232,67,168);
    private int bg = Color.rgb(10,8,13);
    private int card = Color.rgb(25,19,28);
    private String current = "Mira";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showApp();
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(pink));
        return b;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    private void showApp() {
        root = column(); root.setPadding(18,18,18,18); root.setBackgroundColor(bg);
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = column();
        TextView logo = text("愛", 48, pink, true); logo.setGravity(Gravity.CENTER);
        page.addView(logo);
        TextView title = text("XIT", 27, Color.WHITE, true); title.setGravity(Gravity.CENTER);
        page.addView(title);
        TextView subtitle = text("PAINEL VISUAL", 12, Color.LTGRAY, false); subtitle.setGravity(Gravity.CENTER);
        page.addView(subtitle);
        tabs = new LinearLayout(this); tabs.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"Mira","Visuais","Diversos","Config."};
        for (String name : names) {
            Button b = new Button(this); b.setText(name); b.setTextSize(11);
            b.setTextColor(Color.WHITE);
            b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(65,28,57)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            lp.setMargins(2,14,2,10); tabs.addView(b, lp);
            b.setOnClickListener(v -> { current = name.equals("Config.") ? "Configurações" : name; render(); });
        }
        page.addView(tabs);
        content = column(); page.addView(content);
        TextView note = text("Painel de personalização. Os controles não modificam o Free Fire.", 12, Color.LTGRAY, false);
        note.setPadding(0,18,0,10); page.addView(note);
        scroll.addView(page); root.addView(scroll);
        setContentView(root);
        render();
    }
    private void addCardTitle(String s) {
        TextView t = text(s,18,Color.WHITE,true); t.setPadding(12,14,12,8); content.addView(t);
    }
    private void addSwitch(String label, boolean checked) {
        Switch sw = new Switch(this); sw.setText(label); sw.setTextColor(Color.WHITE);
        sw.setChecked(checked); sw.setPadding(12,8,12,8);
        content.addView(sw);
    }
    private void render() {
        content.removeAllViews();
        if (current.equals("Mira")) {
            addCardTitle("🎯 Ajustes de mira (visual)");
            TextView label = text("Nível visual: 50",14,Color.WHITE,false); label.setPadding(12,8,12,0); content.addView(label);
            SeekBar bar = new SeekBar(this); bar.setMax(100); bar.setProgress(50); content.addView(bar);
            bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onProgressChanged(SeekBar s, int p, boolean u) { label.setText("Nível visual: " + p); }
                public void onStartTrackingTouch(SeekBar s) {}
                public void onStopTrackingTouch(SeekBar s) {}
            });
            addSwitch("Indicador visual",true); addSwitch("Estabilização (demonstração)",true);
        } else if (current.equals("Visuais")) {
            addCardTitle("👁️ Aparência"); addSwitch("Tema neon rosa",true); addSwitch("Mostrar logo 愛",true); addSwitch("Animações",true);
        } else if (current.equals("Diversos")) {
            addCardTitle("⚡ Diversos"); addSwitch("HUD compacto",false); addSwitch("Efeitos do painel",true);
            Button b = button("RESTAURAR PAINEL"); b.setOnClickListener(v -> Toast.makeText(this,"Painel aberto",Toast.LENGTH_SHORT).show()); content.addView(b);
        } else {
            addCardTitle("⚙️ Configurações"); addSwitch("Tema escuro",true);
            Button b = button("RESTAURAR PADRÃO"); b.setOnClickListener(v -> { current="Mira"; render(); Toast.makeText(this,"Padrão restaurado",Toast.LENGTH_SHORT).show(); }); content.addView(b);
        }
        content.setBackgroundColor(card);
    }
}
